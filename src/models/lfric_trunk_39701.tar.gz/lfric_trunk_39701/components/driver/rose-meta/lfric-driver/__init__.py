"""
Package initialiser for upgrade macros.
"""
from . import versions
